--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "UFC_borci";
--
-- Name: UFC_borci; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "UFC_borci" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Croatian_Croatia.1250';


ALTER DATABASE "UFC_borci" OWNER TO postgres;

\connect "UFC_borci"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: borbe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.borbe (
    ime character varying(512) NOT NULL,
    prezime character varying(512) NOT NULL,
    protivnik_ime character varying(512),
    protivnik_prezime character varying(512),
    datum_borbe date NOT NULL,
    rezultat character varying(512)
);


ALTER TABLE public.borbe OWNER TO postgres;

--
-- Name: borci; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.borci (
    ime character varying(512) NOT NULL,
    prezime character varying(512) NOT NULL,
    rekord character varying(512),
    "datum_rođenja" date,
    "preciznost_značajnih_udaraca" character varying(512),
    "broj_značajnih_udaraca_po_minuti" real,
    "preciznost_rušenja" character varying(512),
    "broj_rušenja_po_minuti" real,
    datum_prethodne_borbe date NOT NULL
);


ALTER TABLE public.borci OWNER TO postgres;

--
-- Data for Name: borbe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.borbe (ime, prezime, protivnik_ime, protivnik_prezime, datum_borbe, rezultat) FROM stdin;
\.
COPY public.borbe (ime, prezime, protivnik_ime, protivnik_prezime, datum_borbe, rezultat) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: borci; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.borci (ime, prezime, rekord, "datum_rođenja", "preciznost_značajnih_udaraca", "broj_značajnih_udaraca_po_minuti", "preciznost_rušenja", "broj_rušenja_po_minuti", datum_prethodne_borbe) FROM stdin;
\.
COPY public.borci (ime, prezime, rekord, "datum_rođenja", "preciznost_značajnih_udaraca", "broj_značajnih_udaraca_po_minuti", "preciznost_rušenja", "broj_rušenja_po_minuti", datum_prethodne_borbe) FROM '$$PATH$$/3324.dat';

--
-- Name: borbe borbe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borbe
    ADD CONSTRAINT borbe_pkey PRIMARY KEY (ime, prezime, datum_borbe);


--
-- Name: borci borci_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borci
    ADD CONSTRAINT borci_pkey PRIMARY KEY (ime, prezime, datum_prethodne_borbe);


--
-- Name: borci borci_ime_prezime_datum_prethodne_borbe_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borci
    ADD CONSTRAINT borci_ime_prezime_datum_prethodne_borbe_fkey FOREIGN KEY (ime, prezime, datum_prethodne_borbe) REFERENCES public.borbe(ime, prezime, datum_borbe);


--
-- PostgreSQL database dump complete
--

